<?php
$prod = $_POST['prodName'];
$quan= $_POST['productQuantity'];
$total=$_POST['productTotal'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <title >Sirona | Store</title>
    <link rel="shortcut icon" href="Images/DBMS_logo_final.ico" type="image/x-icon">
    <meta name="description" content="This is the description">
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>.
    <script src="store.js" async></script>
   

    
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/twentytwenty/twentytwenty.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css1/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css1/style.css" rel="stylesheet">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://unpkg.com/akar-icons-fonts"></script><link rel="stylesheet" href="./style.css">
    <style>
        body {
            background: linear-gradient(rgba(20, 51, 97, 0.85), rgba(20, 51, 97, 0.85)), url(./img/pharmacy_background.jpg) center center no-repeat;
            background-size: cover;
            font-family: 'Arial', sans-serif;
            font-size: 15 px;
            font-weight: bold;
            margin: 0;
            padding: 0;
        }

         /* Add this to your existing CSS styles */
         @keyframes slideInLeft {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .container {
            
            margin: 50px auto;
            background-color:rgba(6, 163, 218, .7);
            padding: 30px;
            color: rgb(34, 34, 70);
            animation: slideInLeft 1s ease-in-out;
            box-shadow: 0 0 4px;
            
        }

        #appointment-form {
            color: white;
            margin-top: 0px;
            padding: 40px;
            display: flex;
            flex-direction: column;
        }

        .form-row {
            display: flex;
            justify-content:first baseline;
            width: auto;
            vertical-align: middle;
        }

        .form-row label,
        .form-row input,
        .form-row select {
            width: 50%; /* Adjust the width as needed */
        }


        label {
            display: block;
            margin-right: 0px;
            margin-left: 10px;
        }

        input,textarea,select{
            background-color: #e1f7ff;
            color:#6B6A75;
            border-color: white;
            border-style: double;
            box-shadow: 0 0 4px;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="date"],
        input[type="time"],
        select,
        textarea {
            width: 100%;
            padding: 8px;
            margin-right: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
            background-color:  #e1f7ff;
        }

        /* input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #e1f7ff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color:  #e1f7ff;
        } */

        input[type="submit"],.button {
            padding: 10px;
            margin-top: 30px;
            background-color: #193c71;
            color: white;
            font-weight: bold;
            font-size: larger;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover,.button:hover {
            background-color: rgba(6, 163, 218, .7);
            color: black;
        }

        .no-decoration {
            text-decoration: none;
            color: inherit; /* Optionally, this will make the link inherit the color from its parent */
        }

        .error {
            color: #ff0000;
            margin-bottom: 16px;
        }
        
        h1 {
            text-align: center;
        }

        h2 {
            text-align: center;
            font-style: normal;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 8px;
        }

        .searchproduct{
            background-color: whitesmoke;
            height: 40px;
            margin-top: 30px;
            margin-left: 20px;
            border-radius: 5px;
         }
        
    </style>
</head>
<body >
    <header class="main-header"  >
  
       
        <div class="container-fluid bg-light ps-5 pe-0 d-none d-lg-block" style="margin-top: -24px;">
            <div class="row gx-0">
                <div class="col-md-6 text-center text-lg-start mb-2 mb-lg-0">
                    <div class="d-inline-flex align-items-center">
                        <small class="py-2"><i class="far fa-clock text-primary me-2"></i>Opening Hours: Mon - Tues : 6.00 am - 10.00 pm, Sunday Closed </small>
                    </div>
                </div>
                <div class="col-md-6 text-center text-lg-end">
                    <div class="position-relative d-inline-flex align-items-center bg-primary text-white top-shape px-5">
                        <div class="me-3 pe-3 border-end py-2">
                            <p class="m-0" style="color: white;font-weight: 600;"><i class="fa fa-envelope-open me-2"></i>sirona@gmail.com</p>
                        </div>
                        <div class="py-2">
                            <p class="m-0" style="color: white;font-weight: 600;"><i class="fa fa-phone-alt me-2"></i>+91 8420559550</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Topbar End -->
    
       
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm px-5 py-3 py-lg-0">
            <a href="index.html" class="navbar-brand p-0">
                <h1 class="m-0 text-primary"><h1 class="m-0 text-primary" style="text-align: left;"><img src="img/logo.png" alt="" height="10%" width="10%">irona</h1>
    
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.html" class="nav-item nav-link">Home</a>
                    <a href="about.html" class="nav-item nav-link active">About</a>
                    <a href="service.html" class="nav-item nav-link">Service</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">See Also</a>
                        <div class="dropdown-menu m-0">
                            <a href="price.html" class="dropdown-item">Health Records</a>
                            <a href="team.html" class="dropdown-item">Medical Shop</a>  
                            <a href="appointment.html" class="dropdown-item">Appointment</a>
                        </div>
                    </div>
                    <a href="contact.html" class="nav-item nav-link">Contact</a>
                  
                </div>
                <button type="button" class="btn text-dark" data-bs-toggle="modal" data-bs-target="#searchModal" style="margin-top: -5px;"><i class="fa fa-search"></i></button>
                <a href="appointment.html" class="btn btn-primary py-2 px-4 ms-3" style="background-color: #06A3DA;;">Appointment</a>
            </div>
        </nav>
        <!-- Navbar End -->
    
        
        <!-- Hero Start -->
        <div class="container-fluid bg-primary py-5 hero-header mb-5">
            <div class="row py-3">
                <div class="col-12 text-center">
                    <h1 class="display-3 text-white animated zoomIn">Medical Store</h1>
                    <a href="" class="h4 text-white">Buy</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="" class="h4 text-white">Now</a>
                </div>
            </div>
        </div>
            


        <!-- End of navbar-->
    </header>

<div class="container">
    <form id="appointment-form" action="bill.php"  method="post" >
        <div>
        <h1 style="color: white;"> : User Details : </h1>
        <div>
            
            <div class="form-row">
                <label for="" style="color: white;">Product Name</label>
                <input type="text" name="prod_name" value="<?php echo $prod;?>" readonly>
                <label for="" style="color: white;">Quantity</label>
                <input type="text" name="quan" value="<?php echo $quan;?>" readonly>
                <label for="" style="color: white;">Total Price</label>
                <input type="number" name="total" value="<?php echo $total;?>" readonly>
                <input type="text" placeholder="First Name" pattern="[a-zA-Z\s]+" id="name" name="fname" required>
                <input type="text" placeholder="Last Name" pattern="[a-zA-Z\s]+" id="name" name="lname" required>

            </div>
            <div class="form-row">

                <label for="" style="color: white;">Order Date</label>
                
                <input type="date" id="order-date" name="order-date" required value="<?php echo date('Y-m-d'); ?>">

                
            </div>

            <div class="form-row">

                <input type="text" placeholder="Contact" pattern="^\d{10}$" id="contact" name="contact" required>
                <input type="email" placeholder="Email" pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" id="email" name="email" required>
            </div>

            <div class="form-row">
                
                <textarea placeholder="Address" id="address" name="address" rows="4" required></textarea>

            </div>

            <div class="form-row">
            
                <input type="text" placeholder="City/Town" pattern="[a-zA-Z\s]+" id="city" name="city" required>

                <input type="text" placeholder="PinCode" pattern="^\d{6}$" id="pin-code" name="pin-code" required>
            </div>
        </div>
        
        </div>


        <div>




        <!-- payment-->
        <div class="screen flex-center" style="margin-top: 30px;">
            <form class="popup flex p-lg">
              <div class="close-btn pointer flex-center p-sm">
               
              </div>
              
                <!-- CARD FORM -->
                <div class="flex-fill flex-vertical">
                  <div class="header flex-between flex-vertical-center">
                    <div class="flex-vertical-center">
                      <i class="ai-bitcoin-fill size-xl pr-sm f-main-color"></i>
                      <span class="title">
                        <strong>Razor</strong><span>Pay</span>
                      </span>
                    </div>
                    <div class="timer" data-id="timer">
                      <span>0</span><span>5</span>
                      <em>:</em>
                      <span>0</span><span>0</span>
                    </div>
                  </div>
                  <div class="card-data flex-fill flex-vertical">
                    
                    <!-- Card Number -->
                    <div class="flex-between flex-vertical-center">
                      <div class="card-property-title">
                        <strong >Card Number</strong>
                        <span>Enter 16-digit card number on the card</span>
                      </div>
                      <div class="f-main-color pointer"><i class="ai-pencil"></i> Edit</div>
                    </div>
                    
                    <!-- Card Field -->
                    <div class="flex-between">
                      <div class="card-number flex-vertical-center flex-fill">
                        <div class="card-number-field flex-vertical-center flex-fill">
                          
                          
          <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 48" width="24px" height="24px"><path fill="#ff9800" d="M32 10A14 14 0 1 0 32 38A14 14 0 1 0 32 10Z"/><path fill="#d50000" d="M16 10A14 14 0 1 0 16 38A14 14 0 1 0 16 10Z"/><path fill="#ff3d00" d="M18,24c0,4.755,2.376,8.95,6,11.48c3.624-2.53,6-6.725,6-11.48s-2.376-8.95-6-11.48 C20.376,15.05,18,19.245,18,24z"/></svg>
                          
                          
                          
                          <!--
          <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 48" width="24px" height="24px"><path fill="#F44336" d="M33 11A13 13 0 1 0 33 37A13 13 0 1 0 33 11Z"/><path fill="#2196F3" d="M28,24h-8c0-0.682,0.068-1.347,0.169-2h7.661c-0.105-0.685-0.255-1.354-0.464-2h-6.732c0.225-0.694,0.508-1.362,0.84-2h5.051c-0.369-0.709-0.804-1.376-1.293-2h-2.465c0.379-0.484,0.79-0.941,1.233-1.367c-0.226-0.218-0.455-0.432-0.696-0.633c-2.252-1.872-5.146-3-8.304-3C7.82,11,2,16.82,2,24s5.82,13,13,13c3.496,0,6.664-1.388,9-3.633c0.443-0.426,0.854-0.883,1.232-1.367h-2.465c-0.489-0.624-0.923-1.291-1.293-2h5.051c0.333-0.638,0.616-1.306,0.841-2h-6.732c-0.209-0.646-0.358-1.315-0.464-2h7.661C27.932,25.347,28,24.682,28,24z"/></svg>
                          -->
                          
                          <!--
          <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 48" width="24px" height="24px"><path fill="#1565C0" d="M45,35c0,2.209-1.791,4-4,4H7c-2.209,0-4-1.791-4-4V13c0-2.209,1.791-4,4-4h34c2.209,0,4,1.791,4,4V35z"/><path fill="#FFF" d="M15.186 19l-2.626 7.832c0 0-.667-3.313-.733-3.729-1.495-3.411-3.701-3.221-3.701-3.221L10.726 30v-.002h3.161L18.258 19H15.186zM17.689 30L20.56 30 22.296 19 19.389 19zM38.008 19h-3.021l-4.71 11h2.852l.588-1.571h3.596L37.619 30h2.613L38.008 19zM34.513 26.328l1.563-4.157.818 4.157H34.513zM26.369 22.206c0-.606.498-1.057 1.926-1.057.928 0 1.991.674 1.991.674l.466-2.309c0 0-1.358-.515-2.691-.515-3.019 0-4.576 1.444-4.576 3.272 0 3.306 3.979 2.853 3.979 4.551 0 .291-.231.964-1.888.964-1.662 0-2.759-.609-2.759-.609l-.495 2.216c0 0 1.063.606 3.117.606 2.059 0 4.915-1.54 4.915-3.752C30.354 23.586 26.369 23.394 26.369 22.206z"/><path fill="#FFC107" d="M12.212,24.945l-0.966-4.748c0,0-0.437-1.029-1.573-1.029c-1.136,0-4.44,0-4.44,0S10.894,20.84,12.212,24.945z"/></svg>
                          -->
          
                          <input class="numbers" type="password" pattern="^\d{4}$" min="1" max="9999" placeholder="0000"  required>-
                          <input class="numbers" type="password" pattern="^\d{4}$" placeholder="0000" pattern="^\d{4}$" required>-
                          <input class="numbers" type="password" pattern="^\d{4}$" placeholder="0000" pattern="^\d{4}$" required>-
                          <input class="numbers" type="password" pattern="^\d{4}$" placeholder="0000" pattern="^\d{4}$" data-bound="carddigits_mock" data-def="0000" required>
                        </div>
                        <i class="ai-circle-check-fill size-lg f-main-color"></i>
                      </div>
                    </div>
                    
                    <!-- Expiry Date -->
                    <div class="flex-between">
                      <div class="card-property-title">
                        <strong>Expiry Date</strong>
                        <span>Enter the expiration date of the card</span>
                      </div>
                      <div class="card-property-value flex-vertical-center">
                        <div class="input-container half-width">
                          <input class="numbers" data-bound="mm_mock" data-def="00" type="number" min="1" max="12" step="1" placeholder="MM" required>  
                        </div>
                        <span class="m-md">/</span>
                        <div class="input-container half-width">
                          <input class="numbers" data-bound="yy_mock" data-def="01" type="number" min="23" max="99" step="1" placeholder="YY" required>
                        </div>
                      </div>
                    </div>
                    
                    <!-- CCV Number -->
                    <div class="flex-between">
                      <div class="card-property-title">
                        <strong>CVC Number</strong>
                        <span>Enter card verification code from the back of the card</span>
                      </div>
                      <div class="card-property-value">
                        <div class="input-container">
                          <input id="cvc" type="password" pattern="^\d{4}$" required>
                          <i id="cvc_toggler" data-target="cvc" class="ai-eye-open pointer"></i>
                        </div>
                      </div>
                    </div>
                    
                    <!-- Name -->
                    <div class="flex-between">
                      <div class="card-property-title">
                        <strong>Cardholder Name</strong>
                        <span>Enter cardholder's name</span>
                      </div>
                      <div class="card-property-value">
                        <div class="input-container">
                          <input id="name" pattern="[a-zA-Z\s]+" data-bound="name_mock" data-def="Mr. Cardholder" type="text" class="uppercase" placeholder="CARDHOLDER NAME" required>
                          <i class="ai-person"></i>
                        </div>
                      </div>
                    </div>
                    
                    
                  </div>
                 
                </div>
              
                <!-- SIDEBAR -->
                <div class="sidebar flex-vertical">
                  <div>
                  
                  </div>
                  <div class="purchase-section flex-fill flex-vertical">
                    
                    <div class="card-mockup flex-vertical">
                      <div class="flex-fill flex-between">
                        <i class="ai-bitcoin-fill size-xl f-secondary-color"></i>
                        <i class="ai-wifi size-lg f-secondary-color"></i>
                      </div>
                      <div>
                        <div id="name_mock" class="size-md pb-sm uppercase ellipsis">mr. Cardholder</div>
                        <div class="size-md pb-md">
                          <strong>
                            <span class="pr-sm">
                              &#x2022;&#x2022;&#x2022;&#x2022;
                            </span>
                            <span id="carddigits_mock">0000</span>
                          </strong>
                        </div>
                        <div class="flex-between flex-vertical-center">
                          <strong class="size-md">
                            <span id="mm_mock">00</span>/<span id="yy_mock">01</span>
                          </strong>
                          
                          <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 48" width="24px" height="24px"><path fill="#ff9800" d="M32 10A14 14 0 1 0 32 38A14 14 0 1 0 32 10Z"/><path fill="#d50000" d="M16 10A14 14 0 1 0 16 38A14 14 0 1 0 16 10Z"/><path fill="#ff3d00" d="M18,24c0,4.755,2.376,8.95,6,11.48c3.624-2.53,6-6.725,6-11.48s-2.376-8.95-6-11.48 C20.376,15.05,18,19.245,18,24z"/></svg>
                          
                          <!--
                          <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 48" width="24px" height="24px"><path fill="#1565C0" d="M45,35c0,2.209-1.791,4-4,4H7c-2.209,0-4-1.791-4-4V13c0-2.209,1.791-4,4-4h34c2.209,0,4,1.791,4,4V35z"/><path fill="#FFF" d="M15.186 19l-2.626 7.832c0 0-.667-3.313-.733-3.729-1.495-3.411-3.701-3.221-3.701-3.221L10.726 30v-.002h3.161L18.258 19H15.186zM17.689 30L20.56 30 22.296 19 19.389 19zM38.008 19h-3.021l-4.71 11h2.852l.588-1.571h3.596L37.619 30h2.613L38.008 19zM34.513 26.328l1.563-4.157.818 4.157H34.513zM26.369 22.206c0-.606.498-1.057 1.926-1.057.928 0 1.991.674 1.991.674l.466-2.309c0 0-1.358-.515-2.691-.515-3.019 0-4.576 1.444-4.576 3.272 0 3.306 3.979 2.853 3.979 4.551 0 .291-.231.964-1.888.964-1.662 0-2.759-.609-2.759-.609l-.495 2.216c0 0 1.063.606 3.117.606 2.059 0 4.915-1.54 4.915-3.752C30.354 23.586 26.369 23.394 26.369 22.206z"/><path fill="#FFC107" d="M12.212,24.945l-0.966-4.748c0,0-0.437-1.029-1.573-1.029c-1.136,0-4.44,0-4.44,0S10.894,20.84,12.212,24.945z"/></svg>
                          -->
          
                        </div>
                      </div>
                    </div>
                    
                    <ul class="purchase-props">
                      <li class="flex-between">
                        <span>Company</span>
                        <strong>Dabur</strong>
                      </li>
                      <li class="flex-between">
                        <span>Order number</span>
                        <strong>429252965</strong>
                      </li>
                      <li class="flex-between">
                        <span>Product</span>
                        <strong>Artemether</strong>
                      </li>
                      <li class="flex-between">
                        <span>VAT (20%)</span>
                        <strong>Rs 2000.00</strong>
                      </li>
                    </ul>
                  </div>
                  <div class="separation-line"></div>
                  <div class="total-section flex-between flex-vertical-center">
                    <div class="flex-fill flex-vertical">
                      <div class="total-label f-secondary-color">You have to Pay</div>
                      <div>
                        <strong>549</strong>
                        <small>.99 <span class="f-secondary-color">Rs.</span></small>
                      </div>
                    </div>
                    <i class="ai-coin size-lg"></i>
                  </div>
                </div>
            </d>
          </div>
          <!-- partial -->
            
        </div>   
        
        <input type="submit" class="button" value="Pay Now" >
        <button type="button" class="button" onclick="window.history.back()">Back</button>
    </form>

</div>
  <br>
  <br>
  <br>
  <br>

   <!-- Footer Start -->
   <div class="container-fluid bg-dark text-light py-5 wow fadeInUp" data-wow-delay="0.3s" style="margin-top: -75px;">
   
        <div class="row g-5 pt-4">
            <div class="col-lg-3 col-md-6">
                <h3 class="text-white mb-4">Quick Links</h3>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Home</a>
                    <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>About Us</a>
                    <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Our Services</a>
                    <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Latest Blog</a>
                    <a class="text-light" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Contact Us</a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <h3 class="text-white mb-4">Popular Links</h3>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-light mb-2" href="#" ><i class="bi bi-arrow-right text-primary me-2"></i>Home</a>
                    <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>About Us</a>
                    <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Our Services</a>
                    <a class="text-light mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Latest Blog</a>
                    <a class="text-light" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Contact Us</a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <h3 class="text-white mb-4">Get In Touch</h3>
                <p class="mb-2" style="color: white;font-weight: 600;"><i class="bi bi-geo-alt text-primary me-2"></i>Christ University. Bangalore</p>
                <p class="mb-2" style="color: white;font-weight: 600;"><i class="bi bi-envelope-open text-primary me-2"></i>sirona@gmail.com</p>
                <p class="mb-0" style="color: white;font-weight: 600;"><i class="bi bi-telephone text-primary me-2"></i>+91 8420559550</p>
            </div>
            <div class="col-lg-3 col-md-6">
                <h3 class="text-white mb-4">Follow Us</h3>
                <div class="d-flex">
                    <a class="btn btn-lg btn-primary btn-lg-square rounded me-2" href="#"><i class="fab fa-twitter fw-normal"></i></a>
                    <a class="btn btn-lg btn-primary btn-lg-square rounded me-2" href="#"><i class="fab fa-facebook-f fw-normal"></i></a>
                    <a class="btn btn-lg btn-primary btn-lg-square rounded me-2" href="#"><i class="fab fa-linkedin-in fw-normal"></i></a>
                    <a class="btn btn-lg btn-primary btn-lg-square rounded" href="#"><i class="fab fa-instagram fw-normal"></i></a>
                </div>
            </div>
        </div>
   
</div>
<div class="container-fluid text-light py-4" style="background: #051225;">
    
        <div class="row g-0">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-md-0" style="color: white;">&copy; <a class="text-white border-bottom" href="#" >Sirona</a>. All Rights Reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0" style="color: white;">Designed by <a class="text-white border-bottom" href="https://htmlcodex.com">SRSS</a>        
                
                </p>
            </div>
        </div>
   
</div>
<!-- Footer End -->

<script>








      /* COPY INPUT VALUES TO CARD MOCKUP */
const bounds = document.querySelectorAll('[data-bound]');

for(let i = 0; i < bounds.length; i++) {
  const targetId = bounds[i].getAttribute('data-bound');
  const defValue = bounds[i].getAttribute('data-def');
  const targetEl = document.getElementById(targetId);
  bounds[i].addEventListener('keyup', () => targetEl.innerText = bounds[i].value || defValue );
}


/* TOGGLE CVC DISPLAY MODE */
const cvc_toggler = document.getElementById('cvc_toggler');

cvc_toggler.addEventListener('click', () => {
  const target = cvc_toggler.getAttribute('data-target');
  const el = document.getElementById(target);
  el.setAttribute('type', el.type === 'text' ? 'password' : 'text');
});


/* TIMER COUNTDOWN */
const timer = document.querySelector('[data-id=timer]');
let timeLeft = 5 * 60 + 1;

const tick = () => {
  if (timeLeft > 0) {
    timeLeft--;
    const date = new Date('2000-01-01 00:00:00');
    date.setSeconds(timeLeft);
    const str = date.toISOString();
    timer.children[0].innerText = str[14];
    timer.children[1].innerText = str[15];
    timer.children[3].innerText = str[17];
    timer.children[4].innerText = str[18];
  }
}

setInterval(() => { tick(); }, 1000);
tick();
</script>

</body>
</html>
