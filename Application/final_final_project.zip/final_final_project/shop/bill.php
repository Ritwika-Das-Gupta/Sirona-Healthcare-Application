<?php
$prod_name= $_POST['prod_name'];
$quan =$_POST['quan'];
$price=floatval($_POST['total']);
$fname= $_POST['fname'];
$lname=$_POST['lname'];
$o_date=$_POST['order-date'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$address=$_POST['address'];
$city=$_POST['city'];
$pin=$_POST['pin-code'];
$q=mysqli_connect("localhost","root","","sirona");
if(!$q){
	echo "Not connected Please Check Your Internet Connection Or Contact The Administrator at-casatela93@gmail.com:)";
}
$qu = "SELECT * FROM `bill`";
$re = mysqli_query($q,$qu);
$p=0;
while($row = mysqli_fetch_array($re)){
	if($row["email"] == $email ){
		$p=1;
		break;
	}
}

if($p==0){
    // echo'<script>alert("Hi");</script>';
    $sql = "INSERT INTO `bill`(`prod_name`,`quantity`,`price`,`fname`,`lname`,`o_date`,`contact`,`email`,`address`,`city`,`pin`) VALUES ('$prod_name','$quan','$price','$fname','$lname','$o_date','$contact','$email','$address','$city','$pin');";
    if(mysqli_query($q,$sql)){
        echo '<script>alert("Your order has been placed :)");</script>';
    
    }
    else {
        echo "Error: " . $sql . "<br>" . mysqli_error($q);
    }
    
    
}
else if($p==1){
    $sql = "UPDATE `bill` SET 
    `prod_name`='$prod_name', 
    `quantity`='$quan', 
    `price`='$price', 
    `fname`='$fname', 
    `lname`='$lname', 
    `o_date`='$o_date', 
    `contact`='$contact', 
    `email`='$email', 
    `address`='$address', 
    `city`='$city', 
    `pin`='$pin' 
    WHERE `email`='$email'";
    if(mysqli_query($q,$sql)){
        echo '<script>alert("Your order has been placed and bill has been updated :)");</script>';
    
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill</title>
    <style>
        body {
            background: linear-gradient(rgba(20, 51, 97, 0.85), rgba(20, 51, 97, 0.85));
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f0f7f9; /* Light blue background */
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo img {
            width: 100px;
            height: auto;
        }

        h1, h2 {
            text-align: center;
            color: #003366; /* Dark blue text color */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #cce5ff; /* Lighter blue border */
            padding: 12px;
            text-align: left;
            color: #003366; /* Dark blue text color */
        }

        th {
            background-color: #99c2ff; /* Medium blue background */
        }

        .total {
            text-align: right;
            margin-top: 20px;
            color: #003366; /* Dark blue text color */
        }

        .buttons {
            margin-top: 20px;
            text-align: center;
           
        }

        button {
            padding: 10px;
            margin-right: 10px;
            background-color: #003366; /* Dark blue button background */
            color: white;
            font-weight: bold;
            font-size: larger;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #005bb5; /* Medium blue hover effect */
            color: white;
        }

        /* Media query to hide buttons when printing */
        @media print {
            .buttons {
                display: none;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="logo">
        <img src="./img/logo.png" alt="Logo">
    </div>

<div class="container">
    <h1>: Invoice Details : </h1>

    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
        </tr>
        <tr>
            <td><?php echo $prod_name; ?></td>
            <td><?php echo $quan; ?></td>
        </tr>
        <!-- Add more rows as needed -->

        <tr>
            <td class="total">Total:</td>
            <td><?php echo $price; ?></td>
        </tr>
    </table>


    <h2 style="font-weight: 600;">Customer Details</h2>
    <p style="font-weight: 600;">Name: <?php echo $fname . ' ' . $lname; ?></p>
    <p style="font-weight: 600;">Contact: <?php echo $contact; ?></p>
    <p style="font-weight: 600;">Email: <?php echo $email; ?></p>
    <p style="font-weight: 600;">Address: <?php echo $address . ', ' . $city . ', ' . $pin; ?></p>
    <p style="font-weight: 600;">Order Date: <?php echo $o_date;?></p>

</div>

<div class="buttons">
        <button onclick="printBill()">Print</button>
        <button onclick="goBack()">Back</button>
        <button><a href="store.html" style="text-decoration: none; color: inherit;">Home</a></button>
    </div>
<script>
        function printBill() {
        window.print();
    }

    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>
