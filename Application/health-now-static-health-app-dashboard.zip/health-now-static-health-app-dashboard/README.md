# Health Now | Static Health App Dashboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/mikemang/pen/gLyddv](https://codepen.io/mikemang/pen/gLyddv).

Health app dashboard inspired by https://dribbble.com/shots/1738453-Xonom and my recent experiment with Chartists.js.

Also check out my latest post on CSV to JSON to Chartists.js Graph Data: http://codepen.io/mikemang/post/chartists-js-csv-to-json-to-graph-data

Smash the heart and leave your thoughts below