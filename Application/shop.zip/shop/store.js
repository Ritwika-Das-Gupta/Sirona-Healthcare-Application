document.addEventListener('DOMContentLoaded', function () {
    var removeCartItemButtons = document.getElementsByClassName('btn-danger');
    var quantityInputs = document.getElementsByClassName('cart-quantity-input');
    var addToCartButtons = document.getElementsByClassName('shop-item-button');
    var checkoutForm = document.getElementById('checkoutForm');

    for (var i = 0; i < removeCartItemButtons.length; i++) {
        var button = removeCartItemButtons[i];
        button.addEventListener('click', function () {
            removeCartItem(event);
            updateFormFields();
        });
    }

    for (var i = 0; i < quantityInputs.length; i++) {
        var input = quantityInputs[i];
        input.addEventListener('change', function () {
            quantityChanged(event);
            updateFormFields();
        });
    }

    for (var i = 0; i < addToCartButtons.length; i++) {
        var button = addToCartButtons[i];
        button.addEventListener('click', function () {
            addToCartClicked(event);
            updateFormFields();
        });
    }

    function updateFormFields() {
        var cartItemContainer = document.getElementsByClassName('cart-items')[0];
        var cartRows = cartItemContainer.getElementsByClassName('cart-row');
        var productNameInput = document.getElementById('productName');
        var productQuantityInput = document.getElementById('productQuantity');
        var productTotalInput = document.getElementById('productTotal');
        var details = [];

        for (var i = 0; i < cartRows.length; i++) {
            var cartRow = cartRows[i];
            var productTitleElement = cartRow.getElementsByClassName('cart-item-title')[0];
            var quantityElement = cartRow.getElementsByClassName('cart-quantity-input')[0];
            var priceElement = cartRow.getElementsByClassName('cart-price')[0];

            var productTitle = productTitleElement.innerText;
            var quantity = quantityElement.value;
            var price = parseFloat(priceElement.innerText.replace('Rs.', ''));

            details.push({
                productTitle: productTitle,
                quantity: quantity,
                total: quantity * price
            });
        }

        // Set the input values in the checkout form
        productNameInput.value = details.map(detail => detail.productTitle).join(',');
        productQuantityInput.value = details.map(detail => detail.quantity).join(',');
        productTotalInput.value = details.map(detail => detail.total).reduce((acc, val) => acc + val, 0);
                console.log(productNameInput.value,productQuantityInput.value,productTotalInput.value);

        // Uncomment the following line if you want to update the displayed values in the form
        // productNameInput.placeholder = details.map(detail => detail.productTitle).join(',');
        // productQuantityInput.placeholder = details.map(detail => detail.quantity).join(',');
        // productTotalInput.placeholder = details.map(detail => detail.total).reduce((acc, val) => acc + val, 0);
    }

    function addToCartClicked(event) {
        var button = event.target;
        var shopItem = button.parentElement.parentElement;
        var title = shopItem.getElementsByClassName('shop-item-title')[0].innerText;
        var price = shopItem.getElementsByClassName('shop-item-price')[0].innerText;
        var imgSrc = shopItem.getElementsByClassName('shop-item-image')[0].src;
        addItemToCart(title, price, imgSrc);
        updateCartTotal();
        updateFormFields();
    }

    function addItemToCart(title, price, imgSrc) {
        var cartRow = document.createElement('div');
        cartRow.classList.add('cart-row');
        var cartItems = document.getElementsByClassName('cart-items')[0];
        var cartItemNames = cartItems.getElementsByClassName('cart-item-title');

        for (var i = 0; i < cartItemNames.length; i++) {
            if (cartItemNames[i].innerText == title) {
                alert('This item is already added to the cart!');
                return;
            }
        }

        var cartRowContents = `
        <div class="cart-item cart-column">
            <img class="cart-item-image" src="${imgSrc}" width="100" height="100">
            <span class="cart-item-title">${title}</span>
        </div>
        <span class="cart-price cart-column">${price}</span>
        <div class="cart-quantity cart-column">
            <input class="cart-quantity-input" type="number" value="1">
            <button class="btn btn-danger" type="button">REMOVE</button>
        </div>`;

        cartRow.innerHTML = cartRowContents;
        cartItems.append(cartRow);
        cartRow.getElementsByClassName('btn-danger')[0].addEventListener('click', function () {
            removeCartItem(event);
            updateFormFields();
        });
        cartRow.getElementsByClassName('cart-quantity-input')[0].addEventListener('change', function () {
            quantityChanged(event);
            updateFormFields();
        });
    }

    function removeCartItem(event) {
        var buttonClicked = event.target;
        buttonClicked.parentElement.parentElement.remove();
        updateCartTotal();
        updateFormFields();
    }

    function quantityChanged(event) {
        var input = event.target;
        if (isNaN(input.value) || input.value <= 0) {
            input.value = 1;
        }
        updateCartTotal();
        updateFormFields();
    }

    function updateCartTotal() {
        var cartItemContainer = document.getElementsByClassName('cart-items')[0];
        var cartRows = cartItemContainer.getElementsByClassName('cart-row');
        var total = 0;

        for (var i = 0; i < cartRows.length; i++) {
            var cartRow = cartRows[i];
            var priceElement = cartRow.getElementsByClassName('cart-price')[0];
            var quantityElement = cartRow.getElementsByClassName('cart-quantity-input')[0];
            var price = parseFloat(priceElement.innerText.replace('Rs.', ''));
            var quantity = quantityElement.value;
            total += price * quantity;
        }

        document.getElementById('cart-total-price').innerText = 'Rs.' + total;
    }

    checkoutForm.addEventListener('submit', function (event) {
        // Perform any additional actions or validations before submitting the form
        // You can add AJAX or fetch requests to send data to the backend here if needed
    });
});
