# Checkout Form / Payment Gateway

A Pen created on CodePen.io. Original URL: [https://codepen.io/paveltimofeev-the-styleful/pen/WNKxWZv](https://codepen.io/paveltimofeev-the-styleful/pen/WNKxWZv).

Implementation of payment gateway designed by Mohammad Reza Farahzad (https://dribbble.com/shots/17065240-Payment-Gateway-Light-Version) with several fixes. 